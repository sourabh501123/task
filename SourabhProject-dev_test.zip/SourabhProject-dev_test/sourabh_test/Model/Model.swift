//
//  Model.swift
//  sourabh_test
//
//  Created by sourabh khare on 19/03/25.

import Foundation

// MARK: - Model
struct Product: Decodable {
    let id: Int
    let title: String
    let price: Double
    let description: String
    let category: String
    let image: String
}

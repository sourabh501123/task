//
//  ViewController.swift
//  sourabh_test
//
//  Created by sourabh khare on 19/03/25.
//

import UIKit
import SafariServices

class ProductViewController: UIViewController {
    
    //MARK: Outlets
    @IBOutlet weak var productCollectionView: UICollectionView!
    
    //MARK: Local Variables
    private var products: [Product] = []
    var columns: Int = 2 // Default for iPhone
    
    //MARK: Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.intialSetup()
    }
    
    //MARK: Intial Setup
    func intialSetup(){
        self.productCollectionView.delegate = self
        self.productCollectionView.dataSource = self
        updateColumns()
        self.fetchProducts()
    }
    
    //MARK: Fetch products
    func fetchProducts() {
        NetworkManager.shared.fetchProducts { [weak self] products in
            guard let self = self, let products = products else { return }
            self.products = products
            self.productCollectionView.reloadData()
        }
    }
    
    func updateColumns() {
        if UIDevice.current.userInterfaceIdiom == .pad {
            columns = 3
        } else {
            columns = 2
        }
        UIView.animate(withDuration: 0.3) {
            self.productCollectionView.collectionViewLayout.invalidateLayout() // Animate layout update
        }
    }
    
}

//MARK: Extension for collection view methods
extension ProductViewController : UICollectionViewDelegate , UICollectionViewDataSource , UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return products.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ProductCell.identifier, for: indexPath) as! ProductCell
        let product = products[indexPath.row]
        cell.configure(product: product)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selectedPhoto =  products[indexPath.row]
        print(selectedPhoto.image)
        
        if let imageUrl = URL(string: "\(selectedPhoto.image)") {
            UIApplication.shared.open(imageUrl, options: [:], completionHandler: nil)
        } else {
            print("Failed to convert string to URL")
        }
        
    }
    
    //MARK: Dynamic cell size
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let padding: CGFloat = 10
        let collectionViewWidth = collectionView.frame.width
        let cellWidth = (collectionViewWidth - padding * 3) / 2 // 2 columns
        return CGSize(width: cellWidth, height: 150) // Adjust height as needed
    }
    
    // Minimum spacing
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    // MARK: - Animation for Cells
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        cell.alpha = 0
        cell.transform = CGAffineTransform(translationX: 0, y: 50) // Start below
        
        UIView.animate(withDuration: 0.3, delay: 0.05 * Double(indexPath.row), usingSpringWithDamping: 0.8, initialSpringVelocity: 0.5, options: .curveEaseIn, animations: {
            cell.alpha = 1
            cell.transform = .identity // Move to original position
        })
    }
}


// MARK: - Product Cell
class ProductCell: UICollectionViewCell {
    
    static let identifier = "ProductCell"
    
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        imgView.contentMode = .scaleAspectFit
        imgView.layer.cornerRadius = 10
        imgView.clipsToBounds = true
        lblTitle.textAlignment = .center
        
        imgView.translatesAutoresizingMaskIntoConstraints = false
        lblTitle.translatesAutoresizingMaskIntoConstraints = false
        lblTitle.numberOfLines = 7
        lblTitle.textAlignment = .center
        
        NSLayoutConstraint.activate([
            imgView.topAnchor.constraint(equalTo: contentView.topAnchor),
            imgView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            imgView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            imgView.heightAnchor.constraint(equalToConstant: 150)])
    }
    
    func configure(product: Product) {
        lblTitle.text = product.title
        let placeholderImage = UIImage(named: "no-image") // if url not proper formate then show place holder image
        NetworkManager.shared.fetchImage(from: product.image) { [weak self] image in
            self?.imgView.image =   image ?? placeholderImage
        }
    }
}

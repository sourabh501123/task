//
//  Api.swift
//  sourabh_test
//
//  Created by sourabh khare on 19/03/25.
//

//MARK: Constant Api list
class Api_manager {
    static var getProductList = "https://fakestoreapi.com/products"
}

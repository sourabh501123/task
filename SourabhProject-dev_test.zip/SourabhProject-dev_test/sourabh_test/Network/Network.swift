//
//  Model.swift
//  sourabh_test
//
//  Created by sourabh khare on 19/03/25.
//

import UIKit

// MARK: - Network Manager
class NetworkManager {
    
    static let shared = NetworkManager()
    private let cache = NSCache<NSString, UIImage>()
    private init() {}
    
    //MARK: fetch product
    func fetchProducts(completion: @escaping ([Product]?) -> Void) {
        guard let url = URL(string: Api_manager.getProductList) else { return }
        URLSession.shared.dataTask(with: url) { data, _, error in
            guard let data = data, error == nil else {
                completion(nil)
                return
            }
            let products = try? JSONDecoder().decode([Product].self, from: data)
            DispatchQueue.main.async {
                completion(products)
            }
        }.resume()
    }
    
    //MARK: Fetch images from cache
    func fetchImage(from urlString: String, completion: @escaping (UIImage?) -> Void) {
        if let cachedImage = cache.object(forKey: NSString(string: urlString)) {
            completion(cachedImage)
            return
        }
        
        guard let url = URL(string: urlString) else {
            completion(nil)
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, _, error in
            guard let data = data, error == nil, let image = UIImage(data: data) else {
                completion(nil)
                return
            }
            self.cache.setObject(image, forKey: NSString(string: urlString))
            DispatchQueue.main.async {
                completion(image)
            }
        }.resume()
    }
}
